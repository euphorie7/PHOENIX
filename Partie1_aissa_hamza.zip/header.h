//
// Created by ing-mustang on 08/05/24.
//

#ifndef PROJET_2024_LIST_H
#define PROJET_2024_LIST_H

#endif //PROJET_2024_LIST_H


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include <errno.h>
#include <unistd.h>
#include <sys/wait.h>
#include <sys/stat.h>
#include <semaphore.h>
#include <pthread.h>
#include <fcntl.h>
#include <signal.h>
#include <time.h>

typedef struct Structclient
{
    pid_t pid; //pid du process
    int status;
    struct Structclient *next;
    char serveurClient[50];
    char clientServeur[50];
    int distr; // file descriptor du PIPE mkfifo d'envoie de message
    int receps; // idem pour la reception
    pthread_t distr_th; // Pthread qui gère I/O des process
    //pthread_t ecrire;
} Structclient;

typedef struct FIFO
{
    Structclient *tete;
    int fd; // Il contient le fd du fichier
    int taille;
} FIFO;

extern FIFO *Clients; // une variable globale



//Fonction liste chainées

FIFO *newFIFO(char conv[]);
Structclient *newStructclient(pid_t pid, char serveurClient[], char clientServeur[]);
void add(pid_t pid, char serveurClient[], char clientServeur[], FIFO *f);
Structclient *pop(FIFO *f);
void t_join(FIFO* f);
void freeFIFO(FIFO *f);


//Fonction thread

void distribuer(char message[], size_t sizemsg, Structclient *destributeur);
void *distr(void *arg);

