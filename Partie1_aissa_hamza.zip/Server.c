#include "header.h"

#define BIGNUMBER 100000000

FIFO *Clients; // une variable globale


void sighandler(int sig);
void t_join(FIFO* f);
int creerFork(FIFO *f, char serveurClient[], char clientServeur[], char name[]);
void creerPipes(char serveurClient[], char clientServeur[]);
void creerClient(char name[], FIFO *f, int tube1, int tube2);

int main()
{
    // Gestion de signal, en cas d'interruption du programe via Crtl + C
    if (signal(SIGINT, sighandler) == SIG_ERR)
    {
        perror("signal");
        exit(EXIT_FAILURE);
    } // poser le gestionnaire des signaux
    //Avec srand, on génère un nbr aléatoire à partir d'une graîne, qui est le nom du process actuel
    srand(getpid());
    char conv[25];
    // sprintf enregistre le "./conversations/%d.txt" danc conv avec %d étant rand() qui appelle le srand de srand(getpid())
    sprintf(conv, "./conversations/%d.txt", rand());
    Clients = newFIFO(conv);
    int i = 0;
    while (i < 5) // 5 users au max
    {
        char name[20];
        printf("¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤  Server %d ¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤\n", getpid());
        printf("\n");
        printf("choose a name to create ur client\n");
        if (scanf("%15s", name) == 1) // On controle la saisie, si l'output de scanf vaut 0, on skip. ça arrive quand le buffer de stdin est vide.
        {
            creerClient(name, Clients, rand() % BIGNUMBER, rand() % BIGNUMBER);
        }
        i++;
        while (getchar() != '\n');
    }
    pthread_join(Clients->tete->distr_th, NULL);
    t_join(Clients);
}



void sighandler(int sig)
{

    if (sig == SIGINT)
    {
        if (Clients != NULL && Clients->taille != 0)
        {
            Structclient *temp = Clients->tete;
            while (temp != NULL)
            {
                // On trouve la vrai utilité de garder en mémoire les PATH. C'est plus facile de unlink
                unlink(temp->serveurClient);
                unlink(temp->clientServeur);
                // je commence le count de 70
                temp = temp->next;
            }
            printf("\n");
            for (Structclient *temp = Clients->tete; temp != NULL; temp = temp->next)
            {
                printf("hello\n");
                kill(temp->pid, SIGINT);
                sleep(1);
            }

            for (Structclient *temp = Clients->tete; temp != NULL; temp = temp->next)
            {
                waitpid(temp->pid, &(temp->status), 0);
                printf("%d  --> %d, %d\n", temp->pid, WEXITSTATUS(temp->status), WIFEXITED(temp->status));
            }
            freeFIFO(Clients);
        }
        printf("\n le serveur %d  va se terminer au revoir!\n", getpid());
        exit(70);
    }
}


int creerFork(FIFO *f, char serveurClient[], char clientServeur[], char name[])
{
    pid_t pid;

    // Crée un nouveau processus
    pid = fork();

    if (pid == -1)
    {
        // Si fork() échoue, afficher une erreur
        printf("Erreur lors de la création du fork");
        assert(0);
    }//Code fils
    else if (pid == 0)
    {

        // Code exécuté par le processus enfant
        char *message = "Je suis le processus enfant! Mon PID est ";
        fprintf(stdout, "%s %d\n", message, getpid()); //Meilleur que alternative que printf
        char *command[] = {"/usr/bin/xterm", "-T", name, "-e", "./client", serveurClient, clientServeur, name, NULL};
        execv(command[0], command); //Le fils va exec exec2
    }
    else
    {
        // Code exécuté par le processus parent
        printf("Je suis le processus parent! Mon PID est %d, le PID de mon enfant est %d.\n", getpid(), pid);
    }
    return pid;
}

//On va générer les mkfifo client et serveur
void creerPipes(char serveurClient[], char clientServeur[])
{
    mode_t mode = 0660;
    if (mkfifo(serveurClient, mode) == -1)
    {
        perror("mkfifo");
        exit(50); // 50 pour exitfailure des mkfifo
    }
    if (mkfifo(clientServeur, mode) == -1)
    {
        perror("mkfifo");
        exit(50); // 50 pour exitfailure des mkfifo
    }
}

void creerClient(char name[], FIFO *f, int tube1, int tube2)
{
    char serveurClient[50]; // On s'affranchit de ce deux String redondant
    char clientServeur[50];
    // On va plutot utiliser cette cmd dans add
    sprintf(serveurClient, "./pipes/%d", tube1); //On store dans serveur client le PATH du mkfifo1(Non crée pr le moment)
    sprintf(clientServeur, "./pipes/%d", tube2);
    printf("%s\n", serveurClient);
    printf("%s\n", clientServeur);
    pid_t pid = creerFork(f, serveurClient, clientServeur, name);
    if (pid != -1)
    {
        creerPipes(serveurClient, clientServeur);
        add(pid, serveurClient, clientServeur, f);//add se fait avant creerFork désavantage sa consome plus de RAM, car le fils aura en mémoire le toute la structure
        f->tete->distr = open(serveurClient, O_WRONLY); // fd des mkfifo de I/O
        f->tete->receps = open(clientServeur, O_RDONLY); // pensez à une focntion de fermeture des descripteurs
        if (pthread_create(&(f->tete->distr_th), NULL, distr, (void *)f->tete) != 0)
        {
            perror("THREAD :");
            // Traiter l'erreur ici
        }
        printf("thread lire terminé\n");
    }
}
