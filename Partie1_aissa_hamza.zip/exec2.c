#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <semaphore.h>
#include <string.h>
#include <pthread.h>
#include <fcntl.h>
#include <assert.h>
#include <stdint.h>

#define MAX_CHAR 50

typedef struct
{
    char clientServeur[50]; //
    char nom[20];
} path_name;


typedef struct client_info{
    char pseudo[MAX_CHAR];
    char password[MAX_CHAR];
}client_info;


void clearPreviousLine()
{
  // Déplacer le curseur vers le haut
  printf("\033[F");
  // Effacer la ligne
  printf("\033[K");
}


path_name *newPathName(char clientServeur[], char nom[])
{
  path_name *temp = (path_name *)malloc(sizeof(path_name));
  if (temp == NULL)
  {
    return NULL;
  }
  strcpy(temp->clientServeur, clientServeur);
  strcpy(temp->nom, nom);
  return temp;
}

void *readth(void *arg)
{
  char *serveurClient = (char *)arg;
  int fd = open(serveurClient, O_RDONLY);
  char buffer[256];
  size_t bytesread;
  printf("thread exec2 lire en cours ...\n");
  fflush(stdout);
  // memset(buffer, 0, sizeof(buffer));
  while ((bytesread = read(fd, buffer, sizeof(buffer))) > 0)
  {
    //buffer[bytesread] = '\0';
    printf("%s", buffer);
  }
  close(fd);
  return NULL;
}

void *writeth(void *arg)
{
  path_name *temp = (path_name *)arg;
  int fd = open(temp->clientServeur, O_WRONLY);
  char *message = "thread exec2 ecrire en cours ...\n";
  fprintf(stdout, message, sizeof(message));
  fflush(stdout);
  char buffer[256];
  // memset(buffer, 0, sizeof(buffer));
  char dist[300];
  size_t byteswritten;
  while (fgets(buffer, sizeof(buffer), stdin) != NULL)
  {
    clearPreviousLine();
    printf("[Vous] : %s", buffer);
    fflush(stdout);
    // memset(dist, 0, sizeof(dist));
    sprintf(dist, "[%s] : %s", temp->nom, buffer);
    byteswritten = write(fd, dist, sizeof(dist));
    if (byteswritten <= 0)
    {
      close(fd);
      printf("byteswritten error\n");
      assert(12);
      //return NULL;
    }
  }

  close(fd);
  printf("probleme de gets\n");
  assert(13);
  //return(NULL);
}

void connexion()
{
    printf("Login");
}

uint32_t new_account()
{
    client_info *client = (client_info*)malloc(sizeof(client_info));
    if (client == NULL)
    {
        printf("Erreur malloc");
        return 2;
    }
    printf("Commencer par entrer vos infomation personnelles\n");
    printf("Pseudo: ");
    if (fgets(client->pseudo,MAX_CHAR,stdin) == NULL)
    {
        printf("Erreur lecture\n");
        return 3;
    }
    //On teste si le pseudo est dejà dans la BDD en l'envoyant au serv via send
    printf("Mot de passe: ");
    if (fgets(client->password,MAX_CHAR,stdin) == NULL)
    {
        printf("Erreur lecture\n");
        return 3;
    }
    printf("C'est bon pour vous ?\n  Pseudo: %s | Mdp: %s",client->pseudo,client->password);
    printf("Enregistrement des informations dans la BDD users... \n");
    //send()
    //Ecrire sur un fichier base de données cette info
    printf("Enregistrement effectué. Bienvenue\n");

}

void authentification()
{
    char c;
    printf("----- Starting ------ \n");
    printf("Bonjour bienvenue dans notre client de conversation.\n");
    printf("1 - Connexion\n");
    printf("2 - Nouveau venue ? Créer un compte\n");
    printf("3 - Quitter\n");
    uint32_t answer;
    while( scanf("%1u",&answer) == 0)
    {
        printf("Choisiser une option parmi celle dejà présenté\n");
    }
    while ((c = getchar()) != '\n' && c != EOF); // Clear input buffer
    switch (answer)
    {
        case 1:
            //connexion();
            break;
        case 2:
            new_account();
            break;
        case 3:
            printf("A bientôt ! \n");
            exit(0);
    }

}
int main(int argc, char *argv[])
{

    // Output de debugage

  pthread_t lire, ecrire; //On définit deux thread I/O
  if (argc == 4)
  {
    authentification();
    path_name *temp = newPathName(argv[2], argv[3]);
    if (pthread_create(&ecrire, NULL, writeth, (void *)temp) != 0 || pthread_create(&lire, NULL, readth, (void *)argv[1]) != 0)
    {
      perror("THREAD :");
      // Traiter l'erreur ici
    }
    else
    {
      printf("hello %d\n", getpid());
    }
    // pthread_create(&lire, NULL, readth, (void *)argv[1]) != 0 ||
    //  pthread_join(lire, NULL);
    pthread_join(ecrire, NULL);
    pthread_join(lire, NULL);

    free(temp);
  }
  return 34;
}