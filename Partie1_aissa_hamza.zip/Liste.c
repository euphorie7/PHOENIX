//
// Created by ing-mustang on 09/05/24.
//

#include "header.h"


FIFO *newFIFO(char conv[])
{
    FIFO *temp = (FIFO *)malloc(sizeof(FIFO));
    if (temp == NULL)
    {
        printf("erreur creation liste\n");
        assert(0);
    }
    temp->taille = 0;
    temp->fd = open(conv, O_WRONLY | O_CREAT | O_APPEND, 0644);
    //temp->tete = NULL; Pq c'est une bonne idée de le mettre
    return temp; // Retourne la liste
}


Structclient *newStructclient(pid_t pid, char serveurClient[], char clientServeur[])
{
    Structclient *temp = (Structclient *)malloc(sizeof(Structclient));
    if (temp == NULL)
    {
        printf("erreur creation maillon\n");
    }
    temp->pid = pid;
    temp->next = NULL;
    //On clean la zone mémoire de temp->serveurClient par des 0
    memset(temp->serveurClient, 0, sizeof(temp->serveurClient));
    //sprintf(temp->serveurClient, "./pipes/%d", tube1);
    strcpy(temp->serveurClient, serveurClient);

    //Idem pour le clientServeur
    memset(temp->clientServeur, 0, sizeof(temp->clientServeur));
    strcpy(temp->clientServeur, clientServeur);
    temp->distr_th = 0;
    //temp->ecrire = 0;
    temp->distr = 0;
    temp->receps = 0;

    return temp;
}

//La fct add va ajouter à la struct StructCLient les nouvelles info du fifo à la liste. C'est le push d'un file
void add(pid_t pid, char serveurClient[], char clientServeur[], FIFO *f)
{
    Structclient *temp = newStructclient(pid, serveurClient, clientServeur);//On pourrer rajouter argt tube1 et 2 pour store
    //Le if peut être enlever via le Int1
    if (f->taille != 0)
    {
        Structclient *teteFIFO = f->tete;
        temp->next = teteFIFO;
    }
    //temp->next = f->tete;
    f->tete = temp;
    f->taille++;
}

Structclient *pop(FIFO *f)
{
    if (f->taille == 0)
    {
        return NULL;
    }
    Structclient *first = f->tete;
    f->tete = first->next;
    f->taille--;
    return first;
}

void t_join(FIFO *f)
{
    if (f != NULL && f->taille != 0)
    {
        for (Structclient *temp = Clients->tete; temp != NULL; temp = temp->next)
        {
            close(temp->distr);
            close(temp->receps);
            unlink(temp->clientServeur);
            unlink(temp->serveurClient);
            //pthread_join(temp->distr_th, NULL);
            //pthread_join(temp->ecrire, NULL);
            waitpid(temp->pid, &(temp->status), 0);
            printf("%d  --> %d, %d\n", temp->pid, WEXITSTATUS(temp->status), WIFEXITED(temp->status));
            close(f->fd);
            freeFIFO(f);
        }
    }
}


void freeFIFO(FIFO *f)
{
    while (f->tete != NULL)
    {
        free(pop(f));
    }
    free(f);

}