//
// Created by ing-mustang on 08/05/24.
//

#ifndef PROJET_2024_THREAD_H
#define PROJET_2024_THREAD_H

#endif //PROJET_2024_THREAD_H

#include "header.h"


// Mutex
pthread_mutex_t fd_mutex = PTHREAD_MUTEX_INITIALIZER; //Le mutex utilisé pour locker l'ecriture sur le fd distr
pthread_mutex_t conv_mutex = PTHREAD_MUTEX_INITIALIZER; //Le mutex utilisé pour locker l'écriture sur le fichier de conversation


void distribuer(char message[], size_t sizemsg, Structclient *destributeur)
{
    // La 1er partie consiste à parcourir toute la file et à mutex si le maillon de tête de liste ne correspond pas au maillon visité
    Structclient *temp = Clients->tete;
    while (temp != NULL)
    {
        if (temp != destributeur)
        {
            pthread_mutex_lock(&fd_mutex);
            printf("Message à envoyer au FIFO%s, de taille %ld\n",message,sizemsg);
            if (write(temp->distr, message, sizemsg) <= 0)
            {

                printf("probleme d'ecriture ~ mutex\n");
                t_join(Clients);// Code déboulant sur une impasse ?
            }
            pthread_mutex_unlock(&fd_mutex);
        }

        temp = temp->next;
    }
    pthread_mutex_lock(&conv_mutex);
    printf("Message à envoyer au txt %s",message);
    if (write(Clients->fd, message, sizemsg) <= 0)
    {

        printf("probleme d'ecriture ~ mutex\n");
        t_join(Clients);
    }
    pthread_mutex_unlock(&conv_mutex);

    // faut distribuer le buffer puis voir le probleme de la boucle infinie
}
void *distr(void *arg)
{
    Structclient *temp = (Structclient *)arg;
    char buffer[256];
    size_t bytesread;
    printf("thread server lire en cours ...\n");
    fflush(stdout);
    // memset(buffer, 0, sizeof(buffer));
    //Ecoute perpetuelle sur le mkfifo de reception. Si le client du thread dedié envoie un msg dans son mkfifo de reception.On exec la suite
    while ((bytesread = read(temp->receps, buffer, sizeof(buffer))) > 0)
    {
        buffer[bytesread] = '\0';// On ajoute à la fin du buffer le caractère fin de chaîne
        distribuer(buffer, bytesread+1, temp);

        fflush(stdout);
    }
    printf("thread distr va se terminer\n");
    // fonction d nettoyage
    return NULL;
}